NYA Core v2.0.1 - Portable Edition
=====================================

Quick Start:
1. Run NYA_Core.exe
2. Select your game and preset
3. Configure OBS integration if needed

Folders:
- languages/ - Add custom language packs (.json)
- plugins/   - Add custom game plugins (.toml)

Documentation: https://github.com/valkyaha/HitTracker-Release

Note: Settings are stored in %APPDATA%\darkittyvt
