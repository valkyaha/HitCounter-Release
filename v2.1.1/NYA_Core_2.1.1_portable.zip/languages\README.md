# HitCounter Language SDK

Create custom language files for HitCounter by following this guide.

## File Format

Language files are JSON files with the following structure:

```json
{
    "info": {
        "id": "es",
        "name": "Spanish",
        "native_name": "Español",
        "author": "Your Name",
        "version": "1.0.0"
    },
    "strings": {
        "nav.counter": "Contador de Golpes",
        "nav.obs": "Integración OBS",
        ...
    }
}
```

## Creating a Language File

1. Copy the `es.json.example` file to create your language (e.g., `fr.json` for French)
2. Update the `info` section with your language details
3. Translate all strings in the `strings` section
4. Restart HitCounter to see your language in Settings > Language

## String Keys

Here are all available string keys:

### Navigation
- `nav.counter` - Hit Counter menu item
- `nav.obs` - OBS Integration menu item
- `nav.multirun` - Multi-Run menu item
- `nav.games` - Games menu item
- `nav.stats` - Statistics menu item
- `nav.settings` - Settings menu item

### Counter
- `counter.hits` - HITS label
- `counter.addHit` - Add Hit button
- `counter.undoHit` - Undo button
- `counter.bossDefeated` - Boss Defeated button
- `counter.resetRun` - Reset Run button
- `counter.splits` - Splits section title
- `counter.progress` - Progress label

### Status
- `status.idle` - IDLE status
- `status.active` - ACTIVE status
- `status.completed` - COMPLETED status
- `status.hit` - HIT status

### Multi-Run
- `multirun.title` - Multi-Run Mode title
- `multirun.start` - Start Multi-Run button
- `multirun.clearAll` - Clear All button
- `multirun.addGame` - Add Game button
- `multirun.saveAsPB` - Save as PB button
- `multirun.totalHits` - Total Hits label
- `multirun.gamesCompleted` - Games Completed label
- `multirun.totalTime` - Total Time label

### Settings
- `settings.title` - Settings title
- `settings.hotkeys` - Hotkeys section
- `settings.application` - Application section
- `settings.theme` - Theme section
- `settings.language` - Language section
- `settings.data` - Data section
- `settings.autosplitter` - Autosplitter section

### Statistics
- `stats.title` - Statistics title
- `stats.lifetime` - Lifetime Statistics section
- `stats.lifetimeHits` - Total Hits label
- `stats.lifetimeResets` - Total Resets label
- `stats.lifetimeCompletions` - Runs Completed label
- `stats.personalBests` - Personal Bests section

### Common
- `common.save` - Save button
- `common.cancel` - Cancel button
- `common.delete` - Delete button
- `common.edit` - Edit button
- `common.add` - Add button
- `common.remove` - Remove button
- `common.confirm` - Confirm button
- `common.yes` - Yes button
- `common.no` - No button
- `common.error` - Error title
- `common.success` - Success title

## Tips

- You don't need to translate every string - missing strings will fall back to English
- Keep the string keys exactly as shown - they are case-sensitive
- Test your translation by selecting it in Settings > Language
- Share your translations with the community!

## Questions?

Visit https://github.com/your-repo/hitcounter for more information.
